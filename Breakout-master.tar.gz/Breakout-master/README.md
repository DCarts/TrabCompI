# Breakout

Um clone do conhecido jogo "Breakout", desenvolvido para o trabalho final de Computação I da turma de 2017.1 da UFRJ.
