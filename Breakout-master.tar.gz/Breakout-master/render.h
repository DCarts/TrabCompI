/*
 * defs.h
 * 
 * Copyright 2017 Daniel <dcsouza@dcc.ufrj.br>
 *                Guilherme <guiavenas@ufrj.br>
 *                Gabriel <gabrielizotongo@gmail.com>
 */
 
#ifndef GAMERENDER_H
#define GAMERENDER_H

/* Renderiza a tela */
int render();

/* Renderiza o scoreboard na tela */
/*int renderScore();*/

#endif
